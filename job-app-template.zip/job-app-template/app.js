let links = document.querySelector('.links')
function menu(){
  links.classList.toggle('active')
}